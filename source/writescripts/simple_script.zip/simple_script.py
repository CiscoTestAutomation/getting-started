# Import pyATS & Genie
from genie.testbed import load
from ats.log.utils import banner

# ----------------
# Load the testbed
# ----------------
print(banner("Loading testbed"))
testbed = load('testbed.yaml')
print("\n\nSuccessfully loaded testbed '{}'\n\n".format(testbed.name))


# -----------------------
# Connect to device N95_1
# -----------------------
print(banner("Connect to device 'N95_1'"))
device = testbed.devices['N95_1']
device.connect()
print("\n\nSuccessfully connected to device 'N95_1'\n\n")


# ---------------------------------------
# Execute parser to check interface state
# ---------------------------------------
print(banner("Executing parser to verify interface state before unshutting..."))
pre_output = device.parse("show interface Ethernet1/1 brief")

# Verify interface is down before unshutting
pre_status = pre_output['interface']['ethernet']['Eth1/1']['status']
if pre_status == 'down':
    print("\n\nInterface Ethernet1/1 status is 'down' as expected\n\n")
else:
    print("\n\nInterface Ethernet1/1 status is not 'down' as expected\n\n")
    exit()


# -------------------------------------------------
# Unshut the interface by configuring "no shutdown"
# -------------------------------------------------
print(banner("Unshutting interface by configuring 'no shutdown'..."))
device.configure("interface Ethernet1/1\n"
                 " no shutdown")
print("\n\nSuccessfully unshut interface Ethernet1/1\n\n")


# ---------------------------------------
# Execute parser to check interface state
# ---------------------------------------
print(banner("Executing parser to verify interface state after unshutting..."))
post_output = device.parse("show interface Ethernet1/1 brief")

# Verify interface is up after unshutting
post_status = post_output['interface']['ethernet']['Eth1/1']['status']
if post_status == 'up':
    print("\n\nInterface Ethernet1/1 status is 'up' as expected\n\n")
else:
    print("\n\nInterface Ethernet1/1 status is not 'up' as expected\n\n")

